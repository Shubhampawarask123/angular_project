package com.training.fullstack.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

@Table(name = "employees")
@javax.persistence.NamedQueries({ @NamedQuery(name = "getAllEmployee", query = "SELECT emp from Employee emp"),
		@NamedQuery(name = "getActiveEmployee", query = "SELECT emp from Employee emp WHERE active=true")

})
@Entity
public class Employee implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "employee_id")
	private int id;
	private String name;
	private double salary;
	private String email;
	private LocalDate dateOfjoining;
	private boolean active;
	private long phoneNumber;
	
//	@OneToOne(cascade = CascadeType.ALL, fetch=FetchType.EAGER)
//	@JoinColumn(name ="addesss_id")
//	private Address address;
	@ManyToMany(cascade = CascadeType.ALL)
	private Set<Technology> technologies = new HashSet<Technology>();

	
	public Employee(String name, String email, double salary, LocalDate dateOfjoining, boolean active,
			long phoneNumber) {
		super();
		this.name = name;
		this.salary = salary;
		this.email = email;
		this.dateOfjoining = dateOfjoining;
		this.active = active;
		//this.address = address;
		this.phoneNumber = phoneNumber;
		this.technologies= (Set<Technology>) technologies;
	}

	public Employee() {
		super();
	}

//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getDateOfjoining() {
		return dateOfjoining;
	}

	public void setDateOfjoining(LocalDate dateOfjoining) {
		this.dateOfjoining = dateOfjoining;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

//	public Address getAddress() {
//		return address;
//	}
//
//	public void setAddress(Address address) {
//		this.address = address;
//	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Set<Technology> getTechnologies() {
		return technologies;
	}

	public void setTechnologies(Set<Technology> technologies) {
		this.technologies = technologies;
	}

	@Override
	public String toString() {
		return "Employee [id="+id +", name=" + name + ", salary=" + salary + ", email=" + email + ", dateOfjoining=" + dateOfjoining
				+ ", active=" + active + ", phoneNumber=" + phoneNumber + ", technologies=" + technologies + "]";
	}

	

}

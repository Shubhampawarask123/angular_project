package com.training.fullstack.entity;

import java.time.LocalDate;

import java.util.HashSet;
import java.util.Set;
import java.util.List;

import com.training.fullstack.dao.EmployeeDao;
import com.training.fullstack.dao.impl.EmployeeDAOimpl;

public class EmployeeClient {

	public static void main(String[] args) {

		EmployeeDao dao = new EmployeeDAOimpl();

		// Address address=new Address("121/A","Street no 6
		// Hinjewadi","pune","maharastra","India",434567);

		/*
		 * Employee emp1 = new Employee("shyam", "shyam@gmail.com", 12000,
		 * LocalDate.of(2011, 4, 5), false, "Nanded", 9208259559L); Employee emp2 = new
		 * Employee("SHubham", "Shubham@gmail.com", 40000, LocalDate.of(2012, 5, 1),
		 * true, "mumbai", 3208259559L); Employee emp3 = new Employee("sandesh",
		 * "sandesh@gmail.com", 55000, LocalDate.of(20018, 1, 10), true, "Kinwat",
		 * 9908259559L);
		 * 
		 */
//		dao.saveEmployee(emp);
//		dao.saveEmployee(emp1)
//		dao.saveEmployee(emp2);
//		dao.saveEmployee(emp3);

		// dao.getSalary(40000.00);

//		Technology technology1 = new Technology();
//		technology1.setName("Java");
//		Technology technology2 = new Technology();
//		technology2.setName("python");
//
//		Set<Technology> list = new HashSet<Technology>();
//		list.add(technology1);
//		list.add(technology2);

		Employee emp = new Employee("Ram", "ram@gmail.com", 24000, LocalDate.of(2000, 1, 10), true, 8208259559L);
	//	Employee emp = new Employee("Ram", "ram@gmail.com", 24000, LocalDate.of(2000, 1, 10), true, 8208259559L);
		Employee emp1 = new Employee("Shubham", "shub@gmail.com", 240002, LocalDate.of(2000, 2, 10), true, 8908259559L);

	//	emp.setTechnologies(list);
		dao.saveEmployee(emp);
		dao.saveEmployee(emp1);

		List<Employee> list1 = dao.findAll();
		
//		Set<Technology> technologies = list1.get(0).getTechnologies();
		
	//	dao.forEach(System.out::println);
		System.out.println(list1);
	//	emp.setTechnologies(list);
		
		dao.saveEmployee(emp);

		//List<Employee> list1 = dao.findAll();
		
//		Set<Technology> technologies = list1.get(0).getTechnologies();
		
	//	dao.forEach(System.out::println);
		System.out.println(list1);
	}

}

package com.training.fullstack.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.training.fullstack.dao.EmployeeDao;
import com.training.fullstack.entity.Employee;
import com.training.fullstack.util.JPAUtil;

public class EmployeeDAOimpl implements EmployeeDao {

	private EntityManager entityManager;

	public EmployeeDAOimpl() {
		entityManager = JPAUtil.getEntityManager();

	}

	public boolean saveEmployee(Employee employee) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(employee);
			entityManager.getTransaction().commit();
			return true;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}

	public boolean updateEmployee(Employee employee) {

		try {

			entityManager.getTransaction().begin();

			Employee employee2 = entityManager.find(Employee.class, 1);
			System.out.println(" Previous Employee Name : " + employee2.getName());
			System.out.println(" Previous Employee salary : " + employee2.getSalary());

			employee2.setName("Danny");
			employee2.setSalary(12000);

			entityManager.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	public boolean deleteEmployee(Employee employee) {
		try {
			entityManager.getTransaction().begin();
			Employee employee1 = entityManager.find(Employee.class, 7);
			entityManager.remove(employee1);
			entityManager.getTransaction().commit();
			return true;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return false;
	}

	public Employee getEmployeeById(Integer id) {
		entityManager.getTransaction().begin();
		Employee employee3 = entityManager.find(Employee.class, id);
		System.out.println(" Name according to id is  " + employee3.getName());
		System.out.println(" Salary according to id is  " + employee3.getSalary());
		entityManager.getTransaction().commit();

		return null;
	}

//	public List<Employee> getSalary(Double salary) {
//		// TODO Auto-generated method stub
//
//		entityManager.getTransaction().begin();
//		Query query = (Query) entityManager.createNamedQuery(, Employee.class);
//
//		List resultList = query.getResultList();
//
//		resultList.forEach(System.out::println);
//
//		entityManager.getTransaction().commit();
//
//		return null;
//	}

//	@Override
//	public List<Employee> findAll() {
//		entityManager.getTransaction().begin();
//
//		Query query3=
//		TypedQuery<Employee> query = entityManager.createQuery("getAllEmployee", Employee.class);
//
//		List resultList = query.getResultList();
//
//		resultList.forEach(System.out::println);
//
//		entityManager.getTransaction().commit();
//		return null;
//	}

	@Override
	public List<Employee> activeAll() {
		entityManager.getTransaction().begin();

		TypedQuery<Employee> query = entityManager.createQuery("getActiveEmployee", Employee.class);

		entityManager.getTransaction().commit();

		return null;
	}

	@Override
	public List<Employee> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> getSalary(Double salary) {
		// TODO Auto-generated method stub
		return null;
	}

}
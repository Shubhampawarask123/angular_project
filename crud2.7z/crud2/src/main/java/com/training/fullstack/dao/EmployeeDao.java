package com.training.fullstack.dao;

import java.util.List;

import com.training.fullstack.entity.Employee;

public interface EmployeeDao {

	public boolean saveEmployee(Employee employee);

	public boolean updateEmployee(Employee employee);

	public boolean deleteEmployee(Employee employee);

	public Employee getEmployeeById(Integer id);

	public List<Employee> getSalary(Double salary);
	
	public List<Employee> findAll();
	public List<Employee> activeAll();

	
}

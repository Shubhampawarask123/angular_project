package com.training.fullstack.entity;

import java.time.LocalDate;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import java.util.List;

import com.training.fullstack.dao.EmployeeDao;
import com.training.fullstack.dao.impl.EmployeeDAOimpl;

public class EmployeeClient {

	public static void main(String[] args) {
		
		
//
//        entityManager.getTransaction().begin();
//        Employee employee = new Employee();
//        employee.setName("Diwyansh");
//        employee.setSalary(5000);
//        entityManager.persist(employee);
//
		EmployeeDao dao = new EmployeeDAOimpl();

		
//		Employee emp = new Employee("Ram", "ram@gmail.com", 24000, LocalDate.of(2000, 1, 10), true, 8208259559L);
//	//	Employee emp = new Employee("Ram", "ram@gmail.com", 24000, LocalDate.of(2000, 1, 10), true, 8208259559L);
//		Employee emp1 = new Employee("Shubham", "shub@gmail.com", 240002, LocalDate.of(2000, 2, 10), true, 8908259559L);
//
//	//	emp.setTechnologies(list);
//		dao.saveEmployee(emp);
//		dao.saveEmployee(emp1);
//
//		List<Employee> list1 = dao.findAll();
//		
////	
//		System.out.println(list1);
//	
//		
//		dao.saveEmployee(emp);
//
//	
//		System.out.println(list1);
	}

}

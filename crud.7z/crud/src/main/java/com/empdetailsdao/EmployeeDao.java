package com.empdetailsdao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.empdetailsexception.EmpNotFountException;
import com.empdetailsmodel.Employee;
import com.empdetailsservice.IEmpDetailsDao;

public class EmployeeDao implements IEmpDetailsDao {

	Connection con = null;
	PreparedStatement stmt;

	public EmployeeDao() {

		try {
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/test", "postgres", "root");
		} catch (Exception e) {

			System.err.println(e.getMessage());
		}

	}

	public int addEmp(Employee emp) throws SQLException, ClassNotFoundException {
		stmt = con.prepareStatement("insert into emp values(?,?)");
		stmt.setInt(1, emp.getEmpId());
		stmt.setString(2, emp.getEmpName());
		int i = stmt.executeUpdate();
		return i;

	}

	public int delEmp(int empId) throws EmpNotFountException, SQLException {
		stmt = con.prepareStatement("delete from emp where empId=?");
		stmt.setInt(1, empId);
		int i = stmt.executeUpdate();
		return i;
	}

	public Employee updateEmp(int empId, Employee emp) throws SQLException {
		stmt = con.prepareStatement("update emp set empName=? where empId=?");

		stmt.setString(1, emp.getEmpName());
		stmt.setInt(2, empId);
		stmt.executeUpdate();

		return emp;
	}

	public List<Employee> viewEmps() throws SQLException {
		List<Employee> empList = new ArrayList<Employee>();
		Employee e;
		stmt = con.prepareStatement("select * from emp");
		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {
			e = new Employee();
			e.setEmpName(rs.getString(2));
			e.setEmpId(rs.getInt(1));

			empList.add(e);
		}

		return empList;
	}

	public List<Employee> searchById(int empId) throws EmpNotFountException, SQLException {
		stmt = con.prepareStatement("select * from emp where empId=?");
		stmt.setInt(1, empId);
		ResultSet rs = stmt.executeQuery();
		List<Employee> empList = new ArrayList<Employee>();
		Employee emp1;
		while (rs.next()) {
			int empId1 = rs.getInt(1);
			String empName = rs.getString(2);
			emp1 = new Employee(empId1, empName);
			empList.add(emp1);
		}

		return empList;
	}

}

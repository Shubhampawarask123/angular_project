

package com.employeedetailsutil;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmpValidation {
              
              public boolean ValidateEmpName(String empName){
        Pattern ptrn = Pattern.compile("^[A-Z][a-zA-Z]{5,15}$");
        Matcher match = ptrn.matcher(empName);
       
            return match.find()? true:false;}
            
   public boolean ValidateEmpId(int  empId) {
                             return empId<100 ? true:true;

}
}

package com.empdetailsexception;

public class InvalidDetailsException extends Exception {
       
         public InvalidDetailsException(String str) {
             super(str);
       }

}


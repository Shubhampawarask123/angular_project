package com.empdetailsexception;

public class EmpNotFountException  extends Exception{
       public EmpNotFountException(String str)
       {
             super(str);
       }

}


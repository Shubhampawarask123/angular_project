package com.empdetailsexception;

public class ClassNotFoundException extends Exception{
       
public ClassNotFoundException(String str)
{
       super(str);
}
}

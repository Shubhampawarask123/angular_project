package com.empdetailsclient;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.empdetailsexception.EmpNotFountException;
import com.empdetailsexception.InvalidDetailsException;
import com.empdetailsmodel.Employee;
import com.empdetailsservice.EmployeeDetails;
import com.empdetailsservice.IEmpDetails;

public class Client {
	static IEmpDetails empDetails = new EmployeeDetails();

	public static void main(String[] args) throws ClassNotFoundException, EmpNotFountException {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int i = 0;

		int option;
		Employee emp = new Employee();
		char check = 'y';

		do {
			System.out.println("1. Add Employee");
			System.out.println("2. Delete Employee");
			System.out.println("3. Update Employee");
			System.out.println("4. View Employee Details");
			System.out.println("5. View Employee Details by Id");
			System.out.println("6. Exit");
			System.out.println("Enter the operation number : ");
			option = scan.nextInt();

			switch (option)

			{
			case 1:
				System.out.println("Enter Employee Id   : ");
				emp.setEmpId(scan.nextInt());
				System.out.println("Enter Employee Name :");
				emp.setEmpName(scan.next());

				try {
					System.out.println(empDetails.addEmp(emp));
				} catch (InvalidDetailsException e) {
					System.err.println(e.getMessage());
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				}
				break;
			case 2:
				System.out.println("Enter Employee Id to Delete : ");
				int empId = scan.nextInt();
				try {
					System.out.println(empDetails.delEmp(empId));
				} catch (EmpNotFountException e) {
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					System.err.println(e.getMessage());
				}
				break;

			case 3:
				System.out.println("Enter Employee Id to update : ");

				int id = scan.nextInt();
				System.out.println("Enter name to update : ");
				String name = scan.next();
				emp.setEmpId(id);
				emp.setEmpName(name);
				try {
					Employee e = empDetails.updateEmp(id, emp);
					System.out.println("New Employee Details are:");
					System.out.println(e.getEmpId() + " " + e.getEmpName());
				} catch (SQLException e1) {
					System.err.println(e1.getMessage());
				}
				break;
			case 4:

				List<Employee> empList = new ArrayList<Employee>();
				try {
					empList = empDetails.viewEmps();
					for (Employee e : empList) {
						System.out.println(e.getEmpId() + " " + e.getEmpName());
					}
				} catch (EmpNotFountException e1) {
					// TODO Auto-generated catch block
					System.err.println(e1.getMessage());
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					System.err.println(e1.getMessage());
				}

				break;

			case 5:
				List<Employee> empList1 = new ArrayList<Employee>();
				System.out.println("enter the employee id which you want to view ");
				EmployeeDetails empDetails = new EmployeeDetails();

				try {

					empList1 = empDetails.searchById(scan.nextInt());

					for (Employee emp1 : empList1) {
						System.out.println(emp1);
					}

				} catch (SQLException e) {
					System.err.println(e.getMessage());

				} catch (EmpNotFountException e) {
					System.err.println(e.getMessage());

				}
				break;

			case 6:
				System.out.println("Exited");
				System.exit(0);
				break;
			default:
				System.out.println("Wrong Operation Number");

				break;

			}
			System.out.println("Do want to perform anything else? press 'y' for yes or press anything for no :");
			// System.out.println("do you want to continue, press y to continue otherwise
			// press anything.");
			check = scan.next().charAt(0);

			i++;
		} while (check == 'y');

	}

}

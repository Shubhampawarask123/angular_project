package com.empdetailsservice;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.empdetailsdao.EmployeeDao;
import com.empdetailsexception.EmpNotFountException;
import com.empdetailsexception.InvalidDetailsException;
import com.empdetailsmodel.Employee;
import com.employeedetailsutil.EmpValidation;


public class EmployeeDetails implements IEmpDetails{

              IEmpDetailsDao dao=new EmployeeDao();
              List<Employee> empList=new ArrayList<Employee>();
              EmpValidation empval=new EmpValidation();
              

              public String addEmp(Employee emp) throws SQLException, InvalidDetailsException {
                             
                             Employee employee = new Employee();
                             if(empval.ValidateEmpId(emp.getEmpId()))
                                           employee.setEmpId(emp.getEmpId());
                             else
                                           throw new InvalidDetailsException("Employee Id is Not Valid");
              
                             if(empval.ValidateEmpName(emp.getEmpName()))
                             employee.setEmpName(emp.getEmpName());
                             else
                             throw new InvalidDetailsException("Employee Name is Not Valid");
                             
                             int i = 0;
                             try {
                                           i = dao.addEmp(employee);
                             } catch (ClassNotFoundException e) {
                                           // TODO Auto-generated catch block
                                           e.printStackTrace();
                             } catch (InvalidDetailsException e) {
                                           // TODO Auto-generated catch block
                                           e.printStackTrace();
                             } catch (SQLException e) {
                                           // TODO Auto-generated catch block
                                           e.printStackTrace();
                             }
                             empList.add(employee);
                             if(i>0)
                             return "Add Employee Sucessfully...";
                             else
                                           return "Emp is not added in db";
                             
              }

              public String delEmp(int empId) throws EmpNotFountException ,SQLException{
                             int i = dao.delEmp(empId);
                             if(i<=0)
                             {
                                           throw new EmpNotFountException("Emp with Id "+empId+" does not exits.");
                             }
                             return i +"Employee Deleted Sucessfully";
                             
              
              }

              public Employee updateEmp(int empId, Employee emp) throws SQLException {
                             Employee emp1=dao.updateEmp(empId, emp);
                             
                             return emp1;
              }

              public List<Employee> viewEmps() throws EmpNotFountException ,SQLException{
                             List<Employee> empList=dao.viewEmps();
                             
                             if(empList.isEmpty())
                             {
                                           throw new EmpNotFountException("Emp list is empty.");
                             }
                             return empList;
                             
                             
              }
                             public List<Employee> searchById(int empId) throws EmpNotFountException ,SQLException{
                      List<Employee> empList=dao.searchById(empId);

                      if(empList.isEmpty())
                      {
                          throw new EmpNotFountException("Emp list is empty.");
                     }
                      return empList;

                             
              }


}







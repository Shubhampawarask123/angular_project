
package com.empdetailsservice;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import com.empdetailsexception.EmpNotFountException;
import com.empdetailsexception.InvalidDetailsException;
import com.empdetailsmodel.Employee;

public interface IEmpDetailsDao {
              
              public int addEmp(Employee emp) throws InvalidDetailsException,SQLException, ClassNotFoundException;
              public int delEmp(int empId) throws EmpNotFountException,SQLException;
              public Employee updateEmp(int empId, Employee emp) throws SQLException ;
              
              public   List<Employee> viewEmps() throws EmpNotFountException,SQLException;
              
              public   List<Employee> searchById(int empId) throws EmpNotFountException,SQLException;
              

}


package com.training.fullstack.config;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Human implements InitializingBean, DisposableBean {

	private String name;

	public Human() {
		System.out.println("Constructor of human bean is Invoked ");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Initializing method of human bean is created ");
	}

	@Override
	public void destroy() throws Exception {

		System.out.println("Destroy method of human bean is created ");
	}

	

}

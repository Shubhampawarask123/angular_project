package com.training.fullstack.client;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.fullstack.config.Human;

public class HumanClient {
	public static void main(String[] args) {

		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("human.xml");
		Human human = (Human) context.getBean("human", Human.class);

		System.out.println("Name= " + human.getName());

		context.close();

	}

}

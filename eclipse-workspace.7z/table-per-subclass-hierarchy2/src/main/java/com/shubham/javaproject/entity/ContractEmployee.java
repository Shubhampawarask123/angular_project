package com.shubham.javaproject.entity;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "employee")
//@DiscriminatorValue(value = "CE")
//@PrimaryKeyJoinColumn(name="emp_id")
public class ContractEmployee extends Employee {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	private Double HourlyRate;

	
	private Float ContractPeriod;


	public ContractEmployee(Double hourlyRate, Float contractPeriod) {
		super();
		HourlyRate = hourlyRate;
		ContractPeriod = contractPeriod;
	}
	

	public ContractEmployee() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Double getHourlyRate() {
		return HourlyRate;
	}

	public void setHourlyRate(Double hourlyRate) {
		HourlyRate = hourlyRate;
	}

	public Float getContractPeriod() {
		return ContractPeriod;
	}

	public void setContractPeriod(Float contractPeriod) {
		ContractPeriod = contractPeriod;
	}



}
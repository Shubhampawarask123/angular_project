package com.shubham.javaproject.entity;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity

//@DiscriminatorValue(value = "PE").
//@PrimaryKeyJoinColumn(name="emp_id")
public class PermanentEmployee extends Employee {

	private Double salary;

	

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}
	
	

}

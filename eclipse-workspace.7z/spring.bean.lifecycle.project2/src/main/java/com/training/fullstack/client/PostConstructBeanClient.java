package com.training.fullstack.client;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.fullstack.config.PostConstructBean;

public class PostConstructBeanClient {
	public static void main(String[] args) {

//		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("postConstructBean.xml");
//		PostConstructBean postConstructBean = (PostConstructBean) context.getBean("postConstructBean", PostConstructBean.class);
//
//		System.out.println("Name= " + postConstructBean.getName());
//
//		context.close();
		
		ConfigurableApplicationContext context = new AnnotationConfigApplicationContext(PostConstructBean.class);

		PostConstructBean postConstructBean = (PostConstructBean) context.getBean("postConstructBean",
				PostConstructBean.class);

		System.out.println("Name= " + postConstructBean.getName());

		// closing the context object

		context.close();

	}

}

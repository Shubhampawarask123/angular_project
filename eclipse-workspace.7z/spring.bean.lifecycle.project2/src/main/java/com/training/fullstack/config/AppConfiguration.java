package com.training.fullstack.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration

@ComponentScan(basePackages = " com.training.fullstack.config.PostConstructBean")

public class AppConfiguration {
	@Bean(name = "postConstructBean")

	public PostConstructBean getBean() {

		return new PostConstructBean();

	}

}

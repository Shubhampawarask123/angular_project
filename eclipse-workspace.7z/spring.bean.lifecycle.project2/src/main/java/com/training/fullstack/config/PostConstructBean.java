package com.training.fullstack.config;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Repository;

public class PostConstructBean {

	private String name;

	@PostConstruct
	public void init() {
		System.out.println("Inside PostConstruct init()");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
		System.out.println("----------inside set name------------");
	}

	@PreDestroy
	public void destroy() {
		System.out.println("Inside PostConstruct Destroy()");
	}
}

package com.shubham.javaproject.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.query.Query;

import com.shubham.javaproject.entity.Employee;

public class EmployeeClient {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();

//		Employee employee = new Employee();
//		employee.setName("Naveen");
//		employee.setSalary(45000);
//		entityManager.persist(employee); // insert the object
//		
//		Employee employee1 = new Employee();
//		employee1.setName("Shubham");
//		employee.setSalary(60000);
//		entityManager.persist(employee); // insert the object
//		
//		Employee employee2 = new Employee();
//		employee2.setName("Rohit");
//		employee2.setSalary(35000);
//		entityManager.persist(employee); // insert the object
//
//		Employee emp = entityManager.find(Employee.class, 1);
////		emp.setSalary(emp.getSalary()+emp.getSalary()*10/100);
//		entityManager.merge(emp);

		// entityManager.remove(emp);

		String jqpl = "SELECT employee from Employee employee WHERE employee.salary>40000";
		Query query = (Query) entityManager.createQuery(jqpl,Employee.class);

		List resultList = query.getResultList();

		resultList.forEach(System.out::println);

		entityManager.getTransaction().commit();

		System.out.println("The employee information stored succesfully");

	}

}

package com.training.fullstack.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtil {
	
    private static EntityManagerFactory entityManagerFactory;
    private static EntityManager enitityManager;

    private JPAUtil() {
                   // priavte
    }

    public static EntityManager getEntityManager() {
                   entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");
                   if (enitityManager == null || !enitityManager.isOpen()) {
                                  enitityManager = entityManagerFactory.createEntityManager();
                   }

                   return enitityManager;
    }


}

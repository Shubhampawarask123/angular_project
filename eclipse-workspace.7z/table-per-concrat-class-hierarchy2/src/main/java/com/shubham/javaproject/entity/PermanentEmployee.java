package com.shubham.javaproject.entity;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
//@AttributeOverrides({
//	  @AttributeOverride(name="id", column = @Column(name="id")),
//	  
//	  @AttributeOverride(name="name", column = @Column(name="name")),
//	  @AttributeOverride(name="email",column = @Column(name="email"))
//	})

public class PermanentEmployee extends Employee {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Column(name = "salary")
	private Double salary;
	

	public PermanentEmployee( String name, String email, Double salary) {
		super(name, email);
		this.salary = salary;
	}

	public PermanentEmployee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

}

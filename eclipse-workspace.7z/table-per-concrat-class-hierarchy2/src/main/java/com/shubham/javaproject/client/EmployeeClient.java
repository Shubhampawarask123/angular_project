package com.shubham.javaproject.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.query.Query;

import com.shubham.javaproject.entity.ContractEmployee;
import com.shubham.javaproject.entity.Employee;
import com.shubham.javaproject.entity.PermanentEmployee;
import com.training.fullstack.util.JPAUtil;

public class EmployeeClient {
	public static void main(String[] args) {
//		 EntityManagerFactory factory =Persistence.createEntityManagerFactory("JPA-PU");
	//	EntityManager entityManager = factory.createEntityManager();
		EntityManager entityManager = JPAUtil.getEntityManager();
		entityManager.getTransaction().begin();
		//Employee emp = new Employee();
		
	//	emp.setName("Shubham");
	//	emp.setEmail("SDKjb@gmaol.dom");
		
//		ContractEmployee ce = new ContractEmployee();
//	//	ce.setEmail("golu@g.mail.com");
//	//	ce.setName("golu");
//		ce.setContractPeriod(1.2f);
//		ce.setHourlyRate(1500.0);

		PermanentEmployee pe = new PermanentEmployee();
		pe.setSalary(50000.00);
		pe.setEmail("rohini@sdc");
		pe.setName("rohini");
	//	entityManager.persist(ce);
		entityManager.persist(pe);
	//	entityManager.persist(emp);

		entityManager.getTransaction().commit();

		System.out.println("The employee information stored succesfully");

	}

}

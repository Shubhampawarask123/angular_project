package com.training.fullstack.client;

//import java.lang.invoke.ClassSpecializer.Factory;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.training.fullstack.config.AppConfiguration;
import com.training.fullstack.model.Employee;
import com.training.fullstack.model.Order;
import com.training.fullstack.model.Product;

public class ProductClient {
	public static void main(String[] args) {

//	
//	Resource resource = new ClassPathResource("beans.xml");
//	BeanFactory factory = new XmlBeanFactory(resource);

//	Product product =(Product) factory.getBean("product");
//	product.setName("Digital Mouse");
//	product.setDescription("Awesome Mouse");
//	
//	System.out.println(product);

//	Application context Implimentation

	//	@SuppressWarnings("resource")
	//	ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
//		Order order = (Order) context.getBean("order");
		

	//	Product product = (Product) context.getBean("product");
//		product.setName("Digital Mouse");
//		product.setDescription("Awesome Mouse");
//		product.setPrice(5550.00);
//		product.setQuantity(7);
	//	System.out.println(product);
		//System.out.println(order.getProduct());
		
//		Employee employee = (Employee) context.getBean("employee");
//		System.out.println(employee.getAddress());
	
		
	//	ApplicationContext context = new ClassPathXmlApplicationContext("beans-constructor.xml");
		
	////	Product product = (Product) context.getBean("product");
//		Order order = (Order) context.getBean("order");
//
//		System.out.println(order.getProduct());
//		
//		
		

		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfiguration.class);
		Product product=(Product) context.getBean("product");
		
		System.out.println(product);
		
	}

}

package com.training.fullstack.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.training.fullstack.model.Product;

@Configuration
@ComponentScan(basePackages = "com.training.fullstack")
public class AppConfiguration {

	@Bean
	public Product getBean() {
		return new Product();
	}
	

}

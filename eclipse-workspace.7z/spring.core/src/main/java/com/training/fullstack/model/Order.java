package com.training.fullstack.model;

public class Order {
	private Integer id;
	private String description;
	private Product product;

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Order(Integer id, String description, Product product) {
		super();
		this.id = id;
		this.description = description;
		this.product = product;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

}

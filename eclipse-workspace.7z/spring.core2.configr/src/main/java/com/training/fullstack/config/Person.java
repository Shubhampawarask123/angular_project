package com.training.fullstack.config;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.training.fullstack.model.Address;

public class Person {
	private List<String> list;
	private Set<String> set;
	private Map<Integer, String> map;
	private Properties prop;
	private List<Address> address;

	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Person(List<String> list, Set<String> set, Map<Integer, String> map, Properties prop,
			List<Address> address) {
		super();
		this.list = list;
		this.set = set;
		this.map = map;
		this.prop = prop;
		this.address = address;
	}

	public Properties getProp() {
		return prop;
	}

	public void setProp(Properties prop) {
		this.prop = prop;
	}

	public List<String> getList() {
		return list;
	}

	public void setList(List<String> list) {
		this.list = list;
	}

	public Set<String> getSet() {
		return set;
	}

	public void setSet(Set<String> set) {
		this.set = set;
	}

	public Map<Integer, String> getMap() {
		return map;
	}

	public void setMap(Map<Integer, String> map) {
		this.map = map;
	}

	public List<Address> getAddress() {
		return address;
	}

	public void setAddress(List<Address> address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Person [list=" + list + ", set=" + set + ", map=" + map + ", prop=" + prop + ", address=" + address
				+ "]";
	}

}

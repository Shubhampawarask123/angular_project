package com.training.fullstack.client;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.training.fullstack.config.Person;

public class ProductClient {
	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		Person person = (Person) context.getBean("person");

		System.out.println("---access list---");
		List<String> list =person.getList();
		System.out.println(person.getList());
		System.out.println(person.getList());

		System.out.println("---access set---");
		Set<String> set = person.getSet();
		Iterator<String> itr = set.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}

		System.out.println("---access map---");
		Map<Integer, String> map = person.getMap();
		System.out.println(map.get(0));
		System.out.println(map.get(1));

		System.out.println("---access properties---");
		Properties prop = person.getProp();
		System.out.println(prop.getProperty("propKeyA"));
		System.out.println(prop.getProperty("propKeyB"));

		// Access Book List
		System.out.println("---Access Book List---");
		System.out.println(person.getAddress().get(0).getCity());
		System.out.println(person.getAddress().get(0).getState());

	}

}

package com.training.fullstack.config;

import com.training.fullstack.model.Address;

public class Person {
	private int id;
	private String name;
	private Address address;

	public Person() {
		super();

	}

	public Person(int id, String name, Address address) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

//	@Override
//	public String toString() {
//		return "Person [id=" + id + ", name=" + name + "]";
//	}

}

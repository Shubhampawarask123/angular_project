package com.training.fullstack.client;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.training.fullstack.config.Person;

public class ProductClient {
	public static void main(String[] args) {
		
	//	ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		Resource resource = new ClassPathResource("beans.xml");
	//	Person person = (Person) resource.getClass("Person");
		BeanFactory factory = new XmlBeanFactory(resource);
		Person person = (Person) factory.getBean("person");

		System.out.println(person.getId());
		System.out.println(person.getName());
		System.out.println(person.getAddress());

		
	}

}
